# LS Companion application diagnostics

Generated: 2026-09-16T16:43:34.228920+00:00
Result: 10 passed, 1 warnings, 11 failed

- [PASS] Configuration schema and persistence: Settings validate and the configuration directory is writable.
- [PASS] Profile IDs, defaults, and targets: Exactly one default profile and all profile identities are valid.
- [PASS] Application and browser profile matching: Every configured target resolves to its intended profile.
- [PASS] Profile create, save, reload, and match behavior: A profile was created, edited, matched, deleted, and verified through real settings reloads.
- [FAIL] Lossless Scaling executable: The configured LosslessScaling.exe is missing or invalid.
- [FAIL] Lossless Scaling Settings.xml: Not run because required setup tests failed: lossless_installation
- [PASS] Hotkey configuration and listener: Hotkey configuration is valid and the required listener is running.
- [FAIL] Automatic profile scaling readiness: Not run because required setup tests failed: lossless_settings
- [PASS] Process and foreground-window discovery: Foreground-window and visible-process discovery responded.
- [PASS] Managed asset store and package manifests: Managed package payloads are present.
- [FAIL] Benchmark workload and PresentMon command: Not run because required setup tests failed: lossless_installation
- [FAIL] Live automatic scaling behavior: Not run because required setup tests failed: autoscale, benchmark
- [FAIL] Live override-hotkey behavior: Not run because required setup tests failed: autoscale_behavior
- [FAIL] Live Lossless Scaling log confirmation: Not run because required setup tests failed: autoscale_behavior
- [FAIL] ReShade selection and injection plan: Not run because required setup tests failed: lossless_installation
- [FAIL] Live ReShade deployment and load confirmation: Not run because required setup tests failed: reshade, autoscale_behavior
- [FAIL] Active add-on deployment integrity: Not run because required setup tests failed: lossless_installation
- [FAIL] Live add-on and proxy deployment behavior: Not run because required setup tests failed: deployment, benchmark
- [PASS] RTSS integration readiness: A real RTSS application profile was written, verified, removed, and its change notification sent.
- [PASS] Windows startup integration: The real Task Scheduler startup entry was toggled, verified, and restored.
- [PASS] Companion runtime and WebSocket state: Core runtime services are instantiated and responding.
- [WARN] Lossless Scaling folder reset: LosslessScaling.exe is unavailable; no managed folder reset was possible.
