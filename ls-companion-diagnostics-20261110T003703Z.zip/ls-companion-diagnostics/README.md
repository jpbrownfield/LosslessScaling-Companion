# LS Companion application diagnostics

Generated: 2026-11-10T00:37:03.410396+00:00
Result: 18 passed, 2 warnings, 7 failed

- [PASS] Configuration schema and persistence: Settings validate and the configuration directory is writable.
- [WARN] Live GPU routing: requested vs. actual GPU: GPU routing remains unverified: Start scaling the affected application, then run this individual test again
- [PASS] Profile IDs, defaults, and targets: Exactly one default profile and all profile identities are valid.
- [PASS] Application and browser profile matching: Every configured target resolves to its intended profile.
- [PASS] Profile create, save, reload, and match behavior: A profile was created, edited, matched, deleted, and verified through real settings reloads.
- [PASS] Lossless Scaling executable: LosslessScaling.exe is configured and present.
- [PASS] Lossless Scaling Settings.xml: Settings.xml parses and contains native profiles.
- [PASS] Hotkey configuration and listener: Hotkey configuration is valid and the required listener is running.
- [PASS] Automatic profile scaling readiness: Autoscale prerequisites are configured.
- [PASS] Process and foreground-window discovery: Foreground-window and visible-process discovery responded.
- [PASS] Managed asset store and package manifests: Managed package payloads are present.
- [PASS] Benchmark workload and PresentMon command: Benchmark workload, verified PresentMon, and launch arguments are ready.
- [FAIL] Live automatic scaling behavior: The real benchmark window did not automatically enter scaling.
- [FAIL] Live override-hotkey behavior: Not run because required setup tests failed: autoscale_behavior
- [FAIL] Live Lossless Scaling log confirmation: Not run because required setup tests failed: autoscale_behavior
- [PASS] ReShade selection and injection plan: Every selected ReShade profile resolves to an injection plan.
- [WARN] Lilium ReShade compilation evidence: No Lilium compilation evidence was found; activate lsc-basic-sharpening and reproduce scaling before rerunning this test.
- [PASS] Active add-on deployment integrity: Active deployment manifest matches files on disk.
- [FAIL] Live add-on and proxy deployment behavior: One or more live add-on deployments or the restoration failed.
- [FAIL] Live ReShade deployment and load confirmation: ReShade was deployed, but its live scaling or runtime confirmation failed.
- [FAIL] Echo Add-on Manager + ReShade runtime: Echo Add-on Manager + ReShade failed deployment, module-load, scaling, or runtime evidence checks.
- [FAIL] Echo Add-on Manager + Neural Rendering runtime: Echo Add-on Manager + Neural Rendering failed deployment, module-load, scaling, or runtime evidence checks.
- [PASS] Lossless Scaling GPU identity mapping: The LS GPU map matches this machine.
- [PASS] RTSS integration readiness: A real RTSS application profile was written, verified, removed, and its change notification sent.
- [PASS] Windows startup integration: The real Task Scheduler startup entry was toggled, verified, and restored.
- [PASS] Companion runtime and WebSocket state: Core runtime services are instantiated and responding.
- [PASS] Lossless Scaling folder reset: Managed add-on files were removed, original files restored, and the prior LS running state restored.
