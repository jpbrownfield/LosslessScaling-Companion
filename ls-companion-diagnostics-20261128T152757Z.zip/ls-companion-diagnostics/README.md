# LS Companion application diagnostics

Generated: 2026-11-28T15:27:57.274722+00:00
Result: 7 passed, 0 warnings, 1 failed

- [PASS] Managed asset store and package manifests: Managed package payloads are present.
- [PASS] Configuration schema and persistence: Settings validate and the configuration directory is writable.
- [PASS] Lossless Scaling executable: LosslessScaling.exe is configured and present.
- [PASS] Benchmark workload and PresentMon command: Benchmark workload, verified PresentMon, and launch arguments are ready.
- [PASS] Process and foreground-window discovery: Foreground-window and visible-process discovery responded.
- [PASS] RTSS integration readiness: A real RTSS application profile was written, verified, removed, and its change notification sent.
- [FAIL] Adaptive RTSS: single-GPU 3090 and monitoring overhead (about 8 minutes): Adaptive RTSS acceptance: failed before verdict. Telemetry, source-cap response, LS benefit, and observer overhead are reported separately.
- [PASS] Lossless Scaling folder reset: Managed add-on files were removed, original files restored, and the prior LS running state restored.
