# LS Companion application diagnostics

Generated: 2026-09-16T18:51:25.642152+00:00
Result: 17 passed, 0 warnings, 5 failed

- [PASS] Configuration schema and persistence: Settings validate and the configuration directory is writable.
- [PASS] Profile IDs, defaults, and targets: Exactly one default profile and all profile identities are valid.
- [PASS] Application and browser profile matching: Every configured target resolves to its intended profile.
- [PASS] Profile create, save, reload, and match behavior: A profile was created, edited, matched, deleted, and verified through real settings reloads.
- [PASS] Lossless Scaling executable: LosslessScaling.exe is configured and present.
- [PASS] Lossless Scaling Settings.xml: Settings.xml parses and contains native profiles.
- [PASS] Hotkey configuration and listener: Hotkey configuration is valid and the required listener is running.
- [PASS] Automatic profile scaling readiness: Autoscale prerequisites are configured.
- [PASS] Process and foreground-window discovery: Foreground-window and visible-process discovery responded.
- [PASS] Managed asset store and package manifests: Managed package payloads are present.
- [PASS] Benchmark workload and PresentMon command: Benchmark workload, verified PresentMon, and launch arguments are ready.
- [PASS] Live automatic scaling behavior: Foreground detection selected the temporary profile and Lossless Scaling confirmed automatic activation.
- [FAIL] Live override-hotkey behavior: The real override-hotkey activation cycle failed.
- [FAIL] Live Lossless Scaling log confirmation: Scaling was not corroborated by a fresh Lossless Scaling log delta.
- [FAIL] ReShade selection and injection plan: One or more ReShade injection plans are invalid.
- [FAIL] Live ReShade deployment and load confirmation: Not run because required setup tests failed: reshade
- [PASS] Active add-on deployment integrity: Active deployment manifest matches files on disk.
- [FAIL] Live add-on and proxy deployment behavior: One or more live add-on deployments or the restoration failed.
- [PASS] RTSS integration readiness: A real RTSS application profile was written, verified, removed, and its change notification sent.
- [PASS] Windows startup integration: The real Task Scheduler startup entry was toggled, verified, and restored.
- [PASS] Companion runtime and WebSocket state: Core runtime services are instantiated and responding.
- [PASS] Lossless Scaling folder reset: Managed add-on files were removed, original files restored, and the prior LS running state restored.
