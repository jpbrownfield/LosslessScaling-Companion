# LS Companion application diagnostics

Generated: 2026-09-16T18:11:56.062347+00:00
Result: 16 passed, 1 warnings, 5 failed

- [PASS] Configuration schema and persistence: Settings validate and the configuration directory is writable.
- [PASS] Profile IDs, defaults, and targets: Exactly one default profile and all profile identities are valid.
- [PASS] Application and browser profile matching: Every configured target resolves to its intended profile.
- [PASS] Profile create, save, reload, and match behavior: A profile was created, edited, matched, deleted, and verified through real settings reloads.
- [PASS] Lossless Scaling executable: LosslessScaling.exe is configured and present.
- [PASS] Lossless Scaling Settings.xml: Settings.xml parses and contains native profiles.
- [PASS] Hotkey configuration and listener: Hotkey configuration is valid and the required listener is running.
- [PASS] Automatic profile scaling readiness: Autoscale prerequisites are configured.
- [PASS] Process and foreground-window discovery: Foreground-window and visible-process discovery responded.
- [PASS] Managed asset store and package manifests: Managed package payloads are present.
- [PASS] Benchmark workload and PresentMon command: Benchmark workload, verified PresentMon, and launch arguments are ready.
- [FAIL] Live automatic scaling behavior: Live scaling workflow raised RuntimeError: Windows did not grant the benchmark foreground ownership
- [FAIL] Live override-hotkey behavior: Not run because required setup tests failed: autoscale_behavior
- [FAIL] Live Lossless Scaling log confirmation: Not run because required setup tests failed: autoscale_behavior
- [FAIL] ReShade selection and injection plan: One or more ReShade injection plans are invalid.
- [FAIL] Live ReShade deployment and load confirmation: Not run because required setup tests failed: reshade, autoscale_behavior
- [PASS] Active add-on deployment integrity: Active deployment manifest matches files on disk.
- [WARN] Live add-on and proxy deployment behavior: No installed add-on packages were available for live deployment.
- [PASS] RTSS integration readiness: A real RTSS application profile was written, verified, removed, and its change notification sent.
- [PASS] Windows startup integration: The real Task Scheduler startup entry was toggled, verified, and restored.
- [PASS] Companion runtime and WebSocket state: Core runtime services are instantiated and responding.
- [PASS] Lossless Scaling folder reset: Managed add-on files were removed, original files restored, and the prior LS running state restored.
