# LS Companion application diagnostics

Generated: 2026-11-23T23:58:54.470484+00:00
Result: 1 passed, 1 warnings, 0 failed

- [WARN] DLSS5 NR: inspect current application without restarting: No LS compute dispatches reached the capture hook. Loading the addon has not established a frame source. Current application and preset were left running.
- [PASS] Lossless Scaling folder reset: Read-only diagnostic; Lossless Scaling was not reset.
