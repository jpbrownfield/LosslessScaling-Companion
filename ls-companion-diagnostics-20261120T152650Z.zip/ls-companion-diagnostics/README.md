# LS Companion application diagnostics

Generated: 2026-11-20T15:26:50.327073+00:00
Result: 2 passed, 0 warnings, 0 failed

- [PASS] DLSS5 NR benchmark reproduction (LSFG 3 + HDR): DLSS5 NR processed benchmark frames with LSFG 3, HDR and Scaling Off; capture trace saved.
- [PASS] Lossless Scaling folder reset: Managed add-on files were removed, original files restored, and the prior LS running state restored.
