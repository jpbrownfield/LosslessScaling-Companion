# LS Companion application diagnostics

Generated: 2026-11-12T19:59:19.961988+00:00
Result: 24 passed, 3 warnings, 1 failed

- [PASS] Configuration schema and persistence: Settings validate and the configuration directory is writable.
- [WARN] Live GPU routing: requested vs. actual GPU: GPU routing remains unverified: Start scaling the affected application, then run this individual test again
- [PASS] Profile IDs, defaults, and targets: Exactly one default profile and all profile identities are valid.
- [PASS] Application and browser profile matching: Every configured target resolves to its intended profile.
- [PASS] Profile create, save, reload, and match behavior: A profile was created, edited, matched, deleted, and verified through real settings reloads.
- [PASS] Lossless Scaling executable: LosslessScaling.exe is configured and present.
- [PASS] Lossless Scaling Settings.xml: Settings.xml parses and contains native profiles.
- [PASS] Hotkey configuration and listener: Hotkey configuration is valid and the required listener is running.
- [PASS] Automatic profile scaling readiness: Autoscale prerequisites are configured.
- [PASS] Process and foreground-window discovery: Foreground-window and visible-process discovery responded.
- [PASS] Managed asset store and package manifests: Managed package payloads are present.
- [PASS] Benchmark workload and PresentMon command: Benchmark workload, verified PresentMon, and launch arguments are ready.
- [PASS] Live automatic scaling behavior: Foreground detection selected the temporary profile and Lossless Scaling confirmed automatic activation.
- [PASS] Live override-hotkey behavior: The registered override hotkey activated and deactivated scaling through the real listener.
- [PASS] Live Lossless Scaling log confirmation: A fresh Lossless Scaling log delta was captured after confirmed scaling.
- [PASS] ReShade selection and injection plan: Every selected ReShade profile resolves to an injection plan.
- [WARN] Lilium ReShade compilation evidence: No Lilium compilation evidence was found; activate lsc-basic-sharpening and reproduce scaling before rerunning this test.
- [PASS] Active add-on deployment integrity: Active deployment manifest matches files on disk.
- [FAIL] Live add-on and proxy deployment behavior: One or more live add-on deployments or the restoration failed.
- [PASS] Live ReShade deployment and load confirmation: ReShade was deployed and produced fresh runtime evidence while scaling the benchmark.
- [PASS] Echo Add-on Manager + ReShade runtime: Echo Add-on Manager + ReShade deployed, loaded its expected modules, and produced fresh runtime evidence.
- [PASS] Echo Add-on Manager + Neural Rendering runtime: Echo Add-on Manager + Neural Rendering deployed, loaded its expected modules, and produced fresh runtime evidence.
- [PASS] Lossless Scaling GPU identity mapping: The saved LS GPU map is consistent with this machine; live rendering is not verified by this test.
- [WARN] Gloam HDR profiles, session helper, and live HDR observer: Quit Gloam once to finish automatic profile setup, then reopen it.
- [PASS] RTSS integration readiness: A real RTSS application profile was written, verified, removed, and its change notification sent.
- [PASS] Windows startup integration: The real Task Scheduler startup entry was toggled, verified, and restored.
- [PASS] Companion runtime and WebSocket state: Core runtime services are instantiated and responding.
- [PASS] Lossless Scaling folder reset: Managed add-on files were removed, original files restored, and the prior LS running state restored.
